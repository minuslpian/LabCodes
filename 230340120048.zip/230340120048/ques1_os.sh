#!/bin/bash
#question a
touch "SecureData.txt"
#question b
sudo adduser sam
#question c
stat -c "%a" SecureData.txt
#question d
cat SecureData.txt | wc -l
#question e
ps -ef
