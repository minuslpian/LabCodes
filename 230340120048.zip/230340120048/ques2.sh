#!/bin/bash
while [ true ]
do
	echo "Enter distinct numbers only"
	read -p "Enter first number: " num1
	read -p "Enter second number: " num2
	read -p "Enter third number: " num3
	if [ $num1 -ne $num2 -a $num1 -ne $num3 -a $num2 -ne $num3 ]
	then
		break
	else
		continue
	fi
done
if [ $num1 -gt $num2 -a $num1 -gt $num3 ]
then
	largenum=$num1
elif [ $num2 -gt $num1 -a $num2 -gt $num3 ]
then
	largenum=$num2
else
	largenum=$num3
fi

if [ $num1 -lt $num2 -a $num1 -lt $num3 ]
then
        smallnum=$num1
elif [ $num2 -lt $num1 -a $num2 -lt $num3 ]
then
	smallnum=$num2
else
        smallnum=$num3
fi

if [[ $largenum -eq $num1 && $smallnum -eq $num3 ]]
then
	midnum=$num3
elif [ $largenum -eq $num2 ]
then
	midnum=$num1
else
	midnum=$num2
fi
fac=1
for (( i=1;i<=midnum;i++ ))
do
        fac=$((fac*i))

done
echo "fact = $fac"
