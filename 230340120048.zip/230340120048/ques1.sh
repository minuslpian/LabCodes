#!/bin/bash
#question a
touch "SecureData.txt"
#question b
sudo adduser sam
#question c
ls -l SecureData.txt | awk -F ' ' '{print $1}'
#question d
cat secureData.txt | wc -l
#question e
ps -all
